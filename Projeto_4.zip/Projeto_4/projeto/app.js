const readline = require('readline');

function validarDataEvento(dataEvento) {
    const dataAtual = new Date();
    const partes = dataEvento.split('/');
    const eventoData = new Date(partes[2], partes[1] - 1, partes[0]); // Formato: ano, m�s (0-11), dia

    return eventoData.setHours(0, 0, 0, 0) >= dataAtual.setHours(0, 0, 0, 0);
}

function validarIdade(idade) {
    return idade >= 18;
}

class Evento {
    constructor(nome, data) {
        this.nome = nome;
        this.data = data;
        this.participantes = [];
        this.palestrantes = [];
    }

    adicionarPessoa(nome, idade, tipo) {
        if (this.participantes.length + this.palestrantes.length >= 100) {
            console.log("Cadastro n�o permitido. Limite de participantes excedido.");
            return;
        }

        if (!validarIdade(idade)) {
            console.log("Cadastro n�o permitido para menores de 18 anos.");
            return;
        }

        if (tipo === "participante") {
            this.participantes.push({ nome, idade });
        } else if (tipo === "palestrante") {
            this.palestrantes.push({ nome, idade });
        } else {
            console.log("Tipo de cadastro inv�lido. Escolha 'participante' ou 'palestrante'.");
            return;
        }

        console.log(`${nome} foi cadastrado como ${tipo}.`);
    }

    listarPessoas() {
        console.log("\n--- Lista de Participantes ---");
        this.participantes.forEach((p, index) => {
            console.log(`${index + 1}. Nome: ${p.nome}, Idade: ${p.idade}`);
        });

        console.log("\n--- Lista de Palestrantes ---");
        this.palestrantes.forEach((p, index) => {
            console.log(`${index + 1}. Nome: ${p.nome}, Idade: ${p.idade}`);
        });
    }
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function cadastroEvento() {
    solicitarNomeEvento();
}

function solicitarNomeEvento() {
    rl.question('Digite o nome do evento: ', (nomeEvento) => {
        if (!nomeEvento.trim()) {
            console.log("O nome do evento n�o pode estar vazio. Por favor, digite novamente.");
            solicitarNomeEvento(); // Solicita novamente o nome do evento
            return;
        }
        solicitarDataEvento(nomeEvento);
    });
}

function solicitarDataEvento(nomeEvento) {
    rl.question('Digite a data do evento (formato DD/MM/AAAA): ', (dataEvento) => {
        // Verifica se a data do evento � v�lida
        if (!validarDataEvento(dataEvento)) {
            console.log("Data do evento inv�lida. Por favor, insira uma nova data.");
            solicitarDataEvento(nomeEvento); // Solicita nova data
            return;
        }

        const evento = new Evento(nomeEvento, dataEvento);
        // Printar nome e data do evento
        console.log(`\nEvento: \nNome: ${evento.nome} \nData: ${evento.data}`);
        cadastrarPessoa(evento);
    });
}

function cadastrarPessoa(evento) {
    rl.question('\nDigite o nome do participante/palestrante: ', (nome) => {
        rl.question('Digite a idade: ', (idade) => {
            idade = parseInt(idade);

            rl.question('Digite o tipo de cadastro (1 - participante / 2 - palestrante): ', (tipo) => {
                tipo = tipo === "1" ? "participante" : tipo === "2" ? "palestrante" : null;

                if (tipo) {
                    evento.adicionarPessoa(nome, idade, tipo);
                } else {
                    console.log("Tipo de cadastro inv�lido.");
                }

                rl.question('Deseja cadastrar outra pessoa? (s/n): ', (resposta) => {
                    if (resposta.toLowerCase() === 's') {
                        cadastrarPessoa(evento);  // Continua cadastrando
                    } else {
                        evento.listarPessoas();  // Lista as pessoas cadastradas
                        confirmarFechamento();  // Pergunta se deseja fechar o terminal
                    }
                });
            });
        });
    });
}

function confirmarFechamento() {
    rl.question('\nPressione Enter para fechar o terminal... ', () => {
        rl.close();  // Fecha o terminal
    });
}

// Executa o cadastro do evento
cadastroEvento();
